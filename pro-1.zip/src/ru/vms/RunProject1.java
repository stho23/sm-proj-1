package ru.vms;

import java.util.Calendar;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Driver class used by graders to launch the program
 * @author Simeon Thomas
 * @author Reeham Anwar
 */
public class RunProject1 {
    public static void main(String[] argos) {
        new Frontend().run();
    }
}
